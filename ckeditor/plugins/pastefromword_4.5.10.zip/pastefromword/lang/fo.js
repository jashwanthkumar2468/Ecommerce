/*
Copyright (c) 2003-2016, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'pastefromword', 'fo', {
	confirmCleanup: 'Teksturin, tú roynir at seta inn, sýnist at stava frá Word. Skal teksturin reinsast fyrst?',
	error: 'Tað eydnaðist ikki at reinsa tekstin vegna ein internan feil',
	title: 'Innrita frá Word',
	toolbar: 'Innrita frá Word'
} );
