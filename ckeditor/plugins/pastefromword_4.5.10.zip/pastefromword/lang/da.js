/*
Copyright (c) 2003-2016, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'pastefromword', 'da', {
	confirmCleanup: 'Den tekst du forsøger at indsætte ser ud til at komme fra Word. Vil du rense teksten før den indsættes?',
	error: 'Det var ikke muligt at fjerne formatteringen på den indsatte tekst grundet en intern fejl',
	title: 'Indsæt fra Word',
	toolbar: 'Indsæt fra Word'
} );
