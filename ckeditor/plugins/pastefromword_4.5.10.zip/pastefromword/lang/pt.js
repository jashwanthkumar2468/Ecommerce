/*
Copyright (c) 2003-2016, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'pastefromword', 'pt', {
	confirmCleanup: 'O texto que pretende colar parece ter sido copiado do Word. Deseja limpá-lo antes de colar?',
	error: 'Não foi possivel limpar a informação colada decido a um erro interno.',
	title: 'Colar do Word',
	toolbar: 'Colar do Word'
} );
