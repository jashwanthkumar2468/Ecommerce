/*
Copyright (c) 2003-2016, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'pastefromword', 'lv', {
	confirmCleanup: 'Teksts, kuru vēlaties ielīmēt, izskatās ir nokopēts no Word. Vai vēlaties to iztīrīt pirms ielīmēšanas?',
	error: 'Iekšējas kļūdas dēļ, neizdevās iztīrīt ielīmētos datus.',
	title: 'Ievietot no Worda',
	toolbar: 'Ievietot no Worda'
} );
