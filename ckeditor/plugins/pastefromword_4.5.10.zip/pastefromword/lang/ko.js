/*
Copyright (c) 2003-2016, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'pastefromword', 'ko', {
	confirmCleanup: '붙여 넣을 내용은 MS Word에서 복사 한 것입니다. 붙여 넣기 전에 정리 하시겠습니까?',
	error: '내부 오류로 붙여 넣은 데이터를 정리 할 수 없습니다.',
	title: 'MS Word 에서 붙여넣기',
	toolbar: 'MS Word 에서 붙여넣기'
} );
